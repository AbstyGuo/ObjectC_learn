//
//  IdCard.m
//  银行系统
//
//  Created by qianfeng on 15-11-9.
//  Copyright (c) 2015年 sunck. All rights reserved.
//

#import "IdCard.h"

@implementation IdCard
-(NSString *)description{
    NSString *string = [NSString stringWithFormat:@"\n姓名:%@\n性别:%@\n民族:%@\n出生年月:%@\n住址:%@\n公民身份证号:%@\n发证机关:%@\n有效期限:%@\n国籍:%@", _name, _sex, _nation, _dateOfBirth, _address, _idNum, _body, _timeLimit, _nationality];
    return string;
}
@end
