//
//  BandCard.m
//  银行系统
//
//  Created by qianfeng on 15-11-9.
//  Copyright (c) 2015年 sunck. All rights reserved.
//

#import "BandCard.h"

@implementation BandCard
-(void)setPerInfo:(PersonInfo *)perInfo{
    _perInfo = perInfo;
}
-(PersonInfo *)perInfo{
    return _perInfo;
}
@end
