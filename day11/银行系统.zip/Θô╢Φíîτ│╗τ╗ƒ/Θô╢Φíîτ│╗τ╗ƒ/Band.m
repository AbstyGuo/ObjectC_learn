//
//  Band.m
//  银行系统
//
//  Created by qianfeng on 15-11-9.
//  Copyright (c) 2015年 sunck. All rights reserved.
//

#import "Band.h"

static Band *band = nil;

@implementation Band
-(id)init{
    if (self = [super init]) {
        _allCardsArray = [[NSMutableArray alloc] init];
    }
    return self;
}
-(void)setAllCardsArray:(NSMutableArray *)allCardsArray{
    _allCardsArray = allCardsArray;
}
-(NSMutableArray *)allCardsArray{
    return _allCardsArray;
}


+(Band *)defaultBand{
    @synchronized(self){
        if (band == nil) {
            band = [[Band alloc] init];
        }
    }
    return band;
}
+(id)allocWithZone:(struct _NSZone *)zone{
    @synchronized(self){
        if (band == nil) {
            band = [super allocWithZone:zone];
        }
    }
    return band;
}
+(void)deleteBand{
    if (band) {
        band = nil;
    }
}



//开户
-(void)openCard{
    NSLog(@"银行开户");
}

@end
